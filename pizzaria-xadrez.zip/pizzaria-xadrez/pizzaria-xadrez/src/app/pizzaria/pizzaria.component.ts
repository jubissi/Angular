import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pizzaria',
  templateUrl: './pizzaria.component.html',
  styleUrls: ['./pizzaria.component.css']
})
export class PizzariaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
