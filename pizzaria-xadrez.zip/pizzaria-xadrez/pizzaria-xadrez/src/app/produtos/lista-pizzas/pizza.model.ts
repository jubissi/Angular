export interface Pizza{
  id: string
  nome: string
  categoria: string
  estimativa: string
  valor: string
  image: string
}
